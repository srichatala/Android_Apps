/** Automatically generated file. DO NOT MODIFY */
package com.example.listofg02_comp304students;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}