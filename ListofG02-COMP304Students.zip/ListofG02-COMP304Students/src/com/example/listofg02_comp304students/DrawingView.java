package com.example.listofg02_comp304students;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

public class DrawingView extends View {

	private Path mPath = new Path();
	private Paint paint = new Paint();

	public DrawingView(Context context) {
		super(context);
		// TODO Auto-generated constructor stub
	}

	public DrawingView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	public DrawingView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		// TODO Auto-generated constructor stub
		
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
		for(int stripe = 0;stripe<=2;++stripe){
		
		if(stripe == 0){
			paint.setColor(Color.RED);
			//canvas.drawRect(left, top, right, bottom, paint);
			canvas.drawRect(0, 0, 75, 150, paint);
		}
		if(stripe ==1){
			paint.setColor(Color.WHITE);
			canvas.drawRect(75, 0, 185, 150, paint);
		}
		if (stripe == 2){
			paint.setColor(Color.RED);
			canvas.drawRect(300, 0, 375, 150, paint);
		}
	}
	}
}
